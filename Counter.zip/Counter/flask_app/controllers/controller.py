from flask import render_template,redirect,request,session,flash

from flask_app.templates import app
from flask_bcrypt import Bcrypt


@app.route("/")
def register():
    test = 0
    if 'num' not in session:
        test = 1
        return render_template("index.html", test=test)
    else:
        return render_template("index.html", num=session['num'], test=test)
@app.route('/destroy_session', methods=['POST'])
def destroy():
    session.clear()
    return redirect("/")

@app.route('/add_one', methods=['POST'])
def add():
    if 'num' in session:
        session['num'] += 1
    else:
        session['num'] = 1
    return redirect("/")